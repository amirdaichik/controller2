//
// Created by amirdaichik on 26/07/2018.
//

#ifndef PROJECT_PICTURE_BUILDER_H
#define PROJECT_PICTURE_BUILDER_H
#include "types.h"
#include "block.h"
#include "picture.h"
typedef char bitmap;
class pictureBuilder{
private:
    coord m_curPos;
	coord m_real_dim;
    pixelData** m_data;
    void updatePos();
public:
    pictureBuilder(coord dim);
    ~pictureBuilder();
	void updateData(bitmap data);
	picture* buildPicture();
};


#endif //PROJECT_PICTURE_H
