//
// Created by amirdaichik on 14/08/2018.
//

#ifndef PROJECT_TYPES_H
#define PROJECT_TYPES_H
#define NULL 0
#if ARDUINO >=100
    #include "Arduino.h"
#else
    #include "WProgram.h"
    #include "pins_arduino.h"
    #include "WConstants.h"
#endif

typedef struct pixelData{
    bool bit;
    pixelData(){
        bit = false;
    }
} pixelData;
typedef struct coord{
    int row;
    int col;
    coord(){
        row =0;
        col =0;
    }
    coord(int r,int c){
        row = r;
        col = c;
    }
	void print()
	{
		Serial.print("rows=");
		Serial.print(row);
		Serial.print(" cols=");
		Serial.print(col);
	}
} coord;
typedef enum direction{RIGHT=0,DOWN=1,LEFT=2,UP=3} direction;
typedef enum{FINISHED_SCREEN,NEW_LINE,NOTHING_TO_UPDATE} paintIterStatus;
typedef enum arrowDirection{A_RIGHT=30,A_RIGHTDOWN = 31,A_DOWN=32,A_LEFTDOWN=33,A_LEFT=34,A_LEFTUP=35, A_UP=36, A_RIGHTUP=37,A_TURNEDRIGHT=38, A_TURNEDLEFT=39} arrowDirection;
typedef enum colorType{RED,GREEN,BLUE} colorType;
typedef char color;
typedef enum paint_picture_status{NO_SUCH_PICTURE,NO_FIT_TO_SCREEN,PAINT_SUCCESS} paint_picture_status;
typedef struct colorData{
    color r;
    color g;
    color b;
    colorData(){
        r = g = b = 0;
    }
    colorData(color sr,color sg,color sb){
        r = sr;
        g = sg;
        b = sb;
    }
	void print()
	{
		Serial.print("(");
		Serial.print((int)r);
		Serial.print(",");
		Serial.print((int)g);
		Serial.print(",");
		Serial.print((int)b);
		Serial.print(") ");
	}
    /*struct colorData& operator=(const struct colorData& other)
        r = other.r;
        g = other.g;
        b = other.b;
    }*/
}colorData;
#endif //PROJECT_TYPES_H
