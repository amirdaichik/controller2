//
// Created by amirdaichik on 14/08/2018.
//

#include "pin.h"
//
// Created by amirdaichik on 26/07/2018.
//

//#include <iostream>

/*class pin{
private
	int m_pin;
public:
	pin();
	pin(int pin);
	void setPin(int pin);
	void toggle();
	void write(int val);
};
class pospin public pin{
private:
	int m_bit;// bit of pos
public:
	pospin();
	pospin(int pin,int bit);
	void setBit(int bit);
};
*/

pin::pin(){
    m_pin = 0;
	m_valid = false;
}
pin::pin(int pin_n){
    m_pin = pin_n;
	m_valid = true;
    write(0);
	
}
void pin::print() {
	Serial.print("pin:");
	switch(m_pin)
	{
		case R0 : {Serial.print("R0"); break;}
		case R1:  {Serial.print("R1"); break;}
		case CLK_PIN : {Serial.print("clk"); break;}
		case OE_PIN:  {Serial.print("oe"); break;}
		case LAT_PIN : {Serial.print("lat"); break;}
		case A : {Serial.print("A"); break;}
		case B : {Serial.print("B"); break;}
		case C : {Serial.print("C"); break;}
		case D : {Serial.print("D"); break;}
		case G0 : {Serial.print("G0"); break;}
		case G1:  {Serial.print("G1"); break;}
		case B0 : {Serial.print("B0"); break;}
		case B1:  {Serial.print("B1"); break;}
		default:  {Serial.print(m_pin); break;}
	}
	Serial.print("\n");
	Serial.print("pin::valid=");
	Serial.print(m_valid);
	Serial.print("\n");
}
void posPin::print() {
	pin::print();
	Serial.print("bit=");
	Serial.print(m_bit);
	Serial.print("\n");
}
int pin::getPin() {
    return m_pin;
}
void pin::setPin(int pin_n){
    //std::cout<<"I am here"<<std::endl;
    m_pin = pin_n;
	m_valid = true;
    write(0);
}
void pin::toggle(bool shouldPrint){
    write(1,shouldPrint);
    write(0,shouldPrint);
}
void pin::write(int val,bool shouldPrint){
	if(!m_valid)
	{
		Serial.print("Trying to print in invalid pin#");
		Serial.print(m_pin);
		Serial.print("\n");
		return;
	}
	if(shouldPrint)
	{
		Serial.print("Write to pin ");
		switch(m_pin)
		{
			case R0 : {Serial.print("R0"); break;}
			case R1:  {Serial.print("R1"); break;}
			case CLK_PIN : {Serial.print("clk"); break;}
			case OE_PIN:  {Serial.print("oe"); break;}
			case LAT_PIN : {Serial.print("lat"); break;}
			case A : {Serial.print("A"); break;}
			case B : {Serial.print("B"); break;}
			case C : {Serial.print("C"); break;}
			case D : {Serial.print("D"); break;}
			case G0 : {Serial.print("G0"); break;}
			case G1:  {Serial.print("G1"); break;}
			case B0 : {Serial.print("B0"); break;}
			case B1:  {Serial.print("B1"); break;}
			default:  {Serial.print(m_pin); break;}
		}
		Serial.print("=");
		Serial.print(val);
		Serial.print("\n");
	}
	if(val){
		digitalWrite(m_pin, HIGH);
	}
	else
	{
		digitalWrite(m_pin, LOW);
	}
}
posPin::posPin() : pin(){
    m_bit = 0;
}
posPin::posPin(int pin_n,int bit): pin(pin_n){
    m_bit = bit;
}
void posPin::setBit(int bit){
    m_bit = bit;
}
void posPin::writeBitFromVal(int val,bool shouldPrint){
    val = (val >> m_bit)%2;
    write(val,shouldPrint);
}

