//
// Created by amirdaichik on 26/07/2018.
//

//#include <iostream>
#include "pictureBuilder.h"
pictureBuilder::pictureBuilder(coord real_dim) {
    m_real_dim = real_dim;
    m_data = new pixelData*[real_dim.row];
    m_data[0] = new pixelData[real_dim.row*real_dim.col];
    for(int i=1;i<real_dim.row;i++)
        m_data[i] = m_data[0] + i*real_dim.col;
}
pictureBuilder::~pictureBuilder()
{
    delete[] m_data[0];
    delete[] m_data;
}
void pictureBuilder::updatePos()
{
    m_curPos.col = (m_curPos.col+BIT_MAP_SIZE)%m_dim.col;
    if(!m_curPos.col)//ASSUMPTION col is 8*b
        m_curPos.row++;
}
int extractBit(bitmap map,int bit)
{
	return (map>>bit)%2;
}
#define BIT_MAP_SIZE 8
void pictureBuilder::updateData(bitmap byte_of_data)
{
    for(int i=0;i<BIT_MAP_SIZE;i++)
    {
        m_data[m_curPos.row][m_curPos.col+i] = extractBit(byte_of_data,BIT_MAP_SIZE-i); // maybe weird endiness
    }
    updatePos();
}
picture* pictureBuilder::buildPicture()
{
    return new picture(m_real_dim,m_data);
}
