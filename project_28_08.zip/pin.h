//
// Created by amirdaichik on 14/08/2018.
//

#ifndef PROJECT_PIN_H
#define PROJECT_PIN_H
#include "types.h"

#define R0 2
#define B0 3
#define R1 4
#define B1 5
#define A 6
#define C 7
#define CLK_PIN 8
#define OE_PIN 9
#define G0 10
#define G1 11
#define B 12
#define D 13
#define LAT_PIN 14

class pin{
private:
    int m_pin;
	bool m_valid;
public:
    pin();
    pin(int pin_n);
    int getPin();
    void setPin(int pin_n);
    void toggle(bool shouldPrint = false);
    void write(int val,bool shouldPrint = false);
	virtual void print();
};
class posPin: public pin{
private:
    int m_bit;// bit of pos
public:
    posPin();
    posPin(int pin_n,int bit);
    void setBit(int bit);
    void writeBitFromVal(int val,bool shouldPrint = false);
	virtual void print();
};

#endif //PROJECT_PIN_H
