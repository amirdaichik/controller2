#include <iostream>
#include "block.h";
#include "picture.h"
#include "serial_cluster_block.h"

int main() {
    //block::test();
    //picture::test();
    serial_cluster_block::test();
    return 0;
}