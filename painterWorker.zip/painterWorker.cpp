//
// Created by amirdaichik on 08/08/2018.
//

//#include <iostream>
#include "painterWorker.h"
painterWorker::painterWorker()
{
	int para = block::getPara();
	m_red = new pin[para];
	m_blue = new pin[para];
	m_green = new pin[para];
}
painterWorker::~painterWorker()
{
	delete[] m_red;
	delete[] m_blue;
	delete[] m_green;
}

void painterWorker::setCluster(referenceSerialCluster* myCluster){
    m_myCluster = myCluster;

	m_curPos.col = m_myCluster->m_numOfCols-1;
	m_curPos.row = 0;
}
//Paint sequence
void painterWorker::paintPixel(){
	int offset = block::getDim()/block::getPara();
	for(int i=0;i<block::getPara();i++)
	{
    	//std::cout<< m_myCluster->m_data_cur[m_curPos.row+i*offset][m_curPos.col].r<<" ";
    	m_red[i].write(m_myCluster->m_data_cur[m_curPos.row+i*offset][m_curPos.col].r);
		m_green[i].write(m_myCluster->m_data_cur[m_curPos.row+i*offset][m_curPos.col].g);
		m_blue[i].write(m_myCluster->m_data_cur[m_curPos.row+i*offset][m_curPos.col].b);
	}
}
//Update coord to the next valid pos
void painterWorker::updateCoord(){ 
    m_curPos.col = (m_curPos.col - 1) % m_myCluster->m_numOfCols;
    if(!m_curPos.col)
    {
        m_curPos.row = (m_curPos.row+1)% (m_myCluster->m_numOfRows/block::getPara());
    }
}
// This function will be in chrage of drawing one pixel, and it will update the current pos. It will return TRUE once it finishes to draw the whole cluster
paintIterStatus painterWorker::paintIter()
{
	int prevRow = m_curPos.row;
    paintPixel();
    updateCoord();
	if(m_curPos.row == 0 && m_curPos.col == (m_myCluster->m_numOfCols-1))
    	return FINISHED_SCREEN;
	if(prevRow != m_curPos.row)
		return NEW_LINE;
	return NOTHING_TO_UPDATE;
}
// This function attaches a painter worker to a pin in the controller
void painterWorker::setPin(colorType t, pin* thePin,int paraId)
{
	pin* changePin;
	switch(t)
	{
		case RED:{ changePin = &m_red[paraId]; break;}
		case GREEN:{ changePin = &m_green[paraId];break;}
		case BLUE:{ changePin = &m_blue[paraId];break;}
	}
	changePin->setPin(thePin->getPin());
}