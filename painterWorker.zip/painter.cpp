//
// Created by amirdaichik on 08/08/2018.
//

//#include <iostream>
#include "painter.h"
#include "screen.h"
painter painter::s_thePainter;

painter::painter()
{
    m_numOfWorkers = 0;
	m_curRow = 0;
}
painter::~painter()
{
    if(m_numOfWorkers)
    {
        delete[] m_refCluster;
        delete[] m_workers;
    }
}
//Get the instance of the painter
painter* painter::getInstance()
{
    return &s_thePainter;
}
//Initialize of the workers
void painter::init(posPin pos[],int numOfClks,pin* clk,int numOfOEs, pin* OEs,int numOfLats, pin* lats, pin** redPins,pin** greenPins,pin** bluePins)
{

	m_pinLats = lats;
	m_pinOEs = OEs;
	m_pinClks = clk;
	
	m_numOfPinClks = numOfClks;
	m_numOfPinOEs = numOfOEs;
	m_numOfPinLats = numOfLats;
	
    m_numOfWorkers = screen::getInstance()->getNumOfClusters();
    m_workers = new painterWorker[m_numOfWorkers];
    m_refCluster = new referenceSerialCluster[m_numOfWorkers];


    for(int i=0;i<m_numOfWorkers;i++) {
        m_refCluster[i].setMyCluster(screen::getInstance()->getCluster(i));
        m_workers[i].setCluster(&m_refCluster[i]);
        for(int j=0;j<block::getPara();j++)
        {
            m_workers[i].setPin(RED,&redPins[i][j],j);
            m_workers[i].setPin(GREEN,&greenPins[i][j],j);
            m_workers[i].setPin(BLUE,&bluePins[i][j],j);
        }
    }
}
//This function will execute the sequence of painting para pixels by all the workers
void painter::paintIter()
{
    paintIterStatus status;
    for(int i=0;i<m_numOfWorkers;i++){ // Write the color for all the clusters
        status = m_workers[i].paintIter();
    }
	for(int i=0;i<m_numOfPinClks;i++) // Move to the next register TODO: What will happen in the last clk??
	{
		m_pinClks[i].toggle();
	}  
	int tmpRow = m_curRow; // I need it because in case I finished the screen, I set the curRow to zero
	switch(status)
	{
		case FINISHED_SCREEN:
		{
			m_curRow = 0;
			switchToNextBuffer(); 
			// No need to add break because finished screen is also next line
		}
		case NEW_LINE:
		{
			for(int i=0;i<m_numOfPinPos;i++) // setup the row register
			{
				m_posPin[i].writeBitFromVal(tmpRow);
			}
			if(m_curRow != 0)
				m_curRow ++;
			for(int i=0;i<m_numOfPinLats;i++)//latch the line
			{
				m_pinLats[i].toggle();
			}
			for(int i=0;i<m_numOfPinOEs;i++) // Output enable? (Should it done every row or once in a screen?)
			{
				m_pinOEs[i].toggle();
			}
			break;
		}	
	}
}
// Switch between old buffer and new buffer
void painter::switchToNextBuffer()
{
    for(int i=0;i<m_numOfWorkers;i++)
    {
        m_refCluster[i].switchData();
    }
}
// Update the next buffer of all the reference serial cluster 
void painter::latchScreen()
{
    for(int i=0;i<m_numOfWorkers;i++)
        m_refCluster[i].updateData();
}
