//
// Created by amirdaichik on 14/08/2018.
//

#ifndef PROJECT_PIN_H
#define PROJECT_PIN_H
#include "types.h"

class pin{
private:
    int m_pin;
	bool m_valid;
public:
    pin();
    pin(int pin_n);
    int getPin();
    void setPin(int pin_n);
    void toggle();
    void write(int val);
};
class posPin: public pin{
private:
    int m_bit;// bit of pos
public:
    posPin();
    posPin(int pin_n,int bit);
    void setBit(int bit);
    void writeBitFromVal(int val);
};

#endif //PROJECT_PIN_H
