//
// Created by amirdaichik on 08/08/2018.
//

#ifndef PROJECT_PAINTER_H
#define PROJECT_PAINTER_H
#include "types.h"
#include "painterWorker.h"
#include "pin.h"
class painter {
private:
    painterWorker* m_workers;// painter workers, each one in charge of one serial cluster
    referenceSerialCluster* m_refCluster; // continues buffers which contains the data of every cluster
    int m_numOfWorkers; // num of workers
    int m_curRow;
    int m_numOfPinPos;
	posPin* m_posPin;
	int m_numOfPinLats;
	int m_numOfPinClks;
	int m_numOfPinOEs;
	pin* m_pinClks;
	pin* m_pinOEs;
	pin* m_pinLats;
	
    painter();
    ~painter();
public:
    static painter s_thePainter;
	//Get the instance of the painter
	static painter* getInstance();
	//Initialize of the workers
	void init(posPin pos[],int numOfPinClks,pin* clk,int numOfPinOEs, pin* OEs,int numOfPinLats, pin* lats, pin** redPins,pin** greenPins,pin** bluePins);
	//This function will execute the sequence of painting para pixels by all the workers
    void paintIter();
	// Update the next buffer of all the reference serial cluster 
    void latchScreen();
	// Switch between old buffer and new buffer
    void switchToNextBuffer();
};


#endif //PROJECT_PAINTER_H
