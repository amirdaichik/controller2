//
// Created by amirdaichik on 14/08/2018.
//

#include "pin.h"
//
// Created by amirdaichik on 26/07/2018.
//

//#include <iostream>

/*class pin{
private
	int m_pin;
public:
	pin();
	pin(int pin);
	void setPin(int pin);
	void toggle();
	void write(int val);
};
class pospin public pin{
private:
	int m_bit;// bit of pos
public:
	pospin();
	pospin(int pin,int bit);
	void setBit(int bit);
};
*/

pin::pin(){
    m_pin = 0;
	m_valid = false;
}
pin::pin(int pin_n){
    m_pin = pin_n;
	m_valid = true;
    write(0);
	
}
int pin::getPin() {
    return m_pin;
}
void pin::setPin(int pin_n){
    //std::cout<<"I am here"<<std::endl;
    m_pin = pin_n;
	m_valid = true;
    write(0);
}
void pin::toggle(){
    write(1);
    write(0);
}
void pin::write(int val){
	if(!m_valid)
	{
		Serial.print("Trying to print in invalid pin#");
		Serial.print(m_pin);
		Serial.print("\n");
		return;
	}
	Serial.print("Write to pin#");
	Serial.print(m_pin);
	if(val){
		Serial.print(" 1\n");
		digitalWrite(m_pin, HIGH);
	}
	else
	{
		Serial.print(" 0\n");
		digitalWrite(m_pin, LOW);
	}
}
posPin::posPin() : pin(){
    m_bit = 0;
}
posPin::posPin(int pin_n,int bit): pin(pin_n){
    m_bit = bit;
}
void posPin::setBit(int bit){
    m_bit = bit;
}
void posPin::writeBitFromVal(int val){
    val = (val >> m_bit)%2;
    write(val);
}

